public class ModernConsole {
    public void run(DigitalGame game) {
        game.playDigital();
    }
}