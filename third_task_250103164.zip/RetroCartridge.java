public class RetroCartridge {
    public void insertCartridge() {
        System.out.println("Retro game is running from the cartridge!");
    }
}