public class Main {
    public static void main(String[] args) {
        ModernConsole console = new ModernConsole();
        RetroCartridge cartridge = new RetroCartridge();

        DigitalGame adapted = new CartridgeAdapter(cartridge);
        console.run(adapted);
    }
}