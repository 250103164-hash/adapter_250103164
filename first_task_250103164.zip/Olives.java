public class Olives implements Pizza {
    private final Pizza pizza;

    public Olives(Pizza pizza) {
        this.pizza = pizza;
    }

    @Override
    public double cost() {
        return pizza.cost() + 1;
    }

    @Override
    public String description() {
        return pizza.description() + ", Olives";
    }
}
