public interface Pizza {
    double cost();
    String description();
}
