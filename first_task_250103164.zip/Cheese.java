public class Cheese implements Pizza {
    private final Pizza pizza;

    public Cheese(Pizza pizza) {
        this.pizza = pizza;
    }

    @Override
    public double cost() {
        return pizza.cost() + 2;
    }

    @Override
    public String description() {
        return pizza.description() + ", Cheese";
    }
}
