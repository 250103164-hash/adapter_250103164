public class PlainPizza implements Pizza {
    @Override
    public double cost() {
        return 5;
    }

    @Override
    public String description() {
        return "Plain Dough & Sauce";
    }
}
