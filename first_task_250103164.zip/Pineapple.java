public class Pineapple implements Pizza {
    private final Pizza pizza;

    public Pineapple(Pizza pizza) {
        this.pizza = pizza;
    }

    @Override
    public double cost() {
        return pizza.cost() + 1.5;
    }

    @Override
    public String description() {
        return pizza.description() + ", Pineapple";
    }
}