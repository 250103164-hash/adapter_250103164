public class Jetpack implements MovementStrategy {
    @Override
    public String move() {
        return "Flying with jetpack at 60 km/h";
    }
}
