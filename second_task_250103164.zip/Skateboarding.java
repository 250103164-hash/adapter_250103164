public class Skateboarding implements MovementStrategy {
    @Override
    public String move() {
        return "Skateboarding at 15 km/h";
    }
}
