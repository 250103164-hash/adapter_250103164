public class Walking implements MovementStrategy {
    @Override
    public String move() {
        return "Walking at 5 km/h";
    }
}
