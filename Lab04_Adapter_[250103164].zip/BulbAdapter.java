public class BulbAdapter implements SmartDevice {

    public static final int DEFAULT_K = 4;

    private final LegacyBulb bulb;
    private final int calibrationSeedK;

    public BulbAdapter(LegacyBulb bulb) {
        this(bulb, DEFAULT_K);
    }

    public BulbAdapter(LegacyBulb bulb, int k) {
        if (bulb == null) {
            throw new IllegalArgumentException("LegacyBulb instance cannot be null.");
        }
        this.bulb = bulb;
        this.calibrationSeedK = k;
    }

    @Override
    public void turnOn() {
        this.bulb.setBrightness(255);
    }

    public void turnon() {
        turnOn();
    }

    @Override
    public void turnOff() {
        this.bulb.setBrightness(0);
    }

    public void turnoff() {
        turnOff();
    }

    @Override
    public boolean isOn() {
        if (!this.bulb.hasPower()) {
            return false;
        }
        return this.bulb.readBrightness() > 0;
    }

    public boolean ison() {
        return isOn();
    }

    @Override
    public int getPowerPercent() {
        if (!this.bulb.hasPower()) {
            return 0;
        }

        int rawBrightness = this.bulb.readBrightness();
        if (rawBrightness == 0) {
            return 0;
        }

        int rawPercent = (rawBrightness * 100) / 255;
        int calibratedPercent = rawPercent + this.calibrationSeedK;

        return Math.min(100, calibratedPercent);
    }
}