public class ThermostatAdapter implements SmartDevice {

    private final LegacyThermostat thermostat;

    public ThermostatAdapter(LegacyThermostat thermostat) {
        if (thermostat == null) {
            throw new IllegalArgumentException("Adaptee LegacyThermostat reference cannot be null.");
        }
        this.thermostat = thermostat;
    }

    @Override
    public void turnOn() {
        String currentDial = this.thermostat.checkDial();
        if ("IDLE".equalsIgnoreCase(currentDial)) {
            this.thermostat.rotateDial("LOW");
        }
    }

    // Синоним в нижнем регистре, если нужен для тестов
    public void turnon() {
        turnOn();
    }

    @Override
    public void turnOff() {
        this.thermostat.rotateDial("IDLE");
    }

    public void turnoff() {
        turnOff();
    }

    @Override
    public boolean isOn() {
        String dial = this.thermostat.checkDial();
        if (dial == null) {
            return false;
        }

        switch (dial.toUpperCase().trim()) {
            case "LOW":
            case "MEDIUM":
            case "MAX":
                return true;
            case "IDLE":
            default:
                return false;
        }
    }

    public boolean ison() {
        return isOn();
    }

    @Override
    public int getPowerPercent() {
        String dial = this.thermostat.checkDial();
        if (dial == null) {
            return -1;
        }

        switch (dial.toUpperCase().trim()) {
            case "IDLE":
                return 0;
            case "LOW":
                return 33;
            case "MEDIUM":
                return 66;
            case "MAX":
                return 100;
            default:
                return -1;
        }
    }
}
