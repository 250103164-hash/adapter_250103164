package com.ecommerce;

/**
 * New class: FakeOrderChecker
 * Decides whether an order is fake/suspicious based on (id, amount).
 */
public class FakeOrderChecker {

    /**
     * @param id     customer ID
     * @param amount order total
     * @return true if the order is fake/suspicious, false if it is legit
     */
    public boolean isFake(String id, double amount) {
        boolean isLegit = id != null && !id.trim().isEmpty()
                && !Double.isNaN(amount) && !Double.isInfinite(amount) && amount > 0;
        boolean isSus = !isLegit;
        return isSus;
    }
}
