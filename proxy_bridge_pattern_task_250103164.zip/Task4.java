interface Device {
    void turnon();
    void turnoff();
    void setVolume(int level);
}

class SmartLight implements Device {
    @Override
    public void turnon() {
        System.out.println("Smart Light glows bright white.");
    }

    @Override
    public void turnoff() {
        System.out.println("Smart Light shuts off.");
    }

    @Override
    public void setVolume(int level) {
        System.out.println("Smart Light brightness set to: " + level + "%");
    }
}

class BasicRemote {
    protected Device device;

    public BasicRemote(Device device) {
        this.device = device;
    }

    public void poweron() {
        device.turnon();
    }

    public void poweroff() {
        device.turnoff();
    }
}

class AdvancedRemote extends BasicRemote {
    public AdvancedRemote(Device device) {
        super(device);
    }

    public void mute() {
        System.out.println("[Remote] Mute button pressed!");
        device.setVolume(0);
    }
}

public class Task4 {
    public static void main(String[] args) {
        Device light = new SmartLight();
        AdvancedRemote remote = new AdvancedRemote(light);

        remote.poweron();
        remote.mute();
    }
}
