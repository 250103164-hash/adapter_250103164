class Radio implements Device {
    @Override
    public void turnon() {
        System.out.println("Radio starts playing static/music.");
    }

    @Override
    public void turnoff() {
        System.out.println("Radio stops playing.");
    }

    @Override
    public void setVolume(int level) {
        System.out.println("Radio volume knob turned to: " + level);
    }
}

class PartyRemote extends BasicRemote {
    public PartyRemote(Device device) {
        super(device);
    }

    public void partyMode() {
        System.out.println("[Party Remote] Pumping up the party!");
        device.turnon();
        device.setVolume(100);
    }
}

public class Task5 {
    public static void main(String[] args) {
        Device radio = new Radio();
        PartyRemote partyRemote = new PartyRemote(radio);

        partyRemote.partyMode();
    }
}
