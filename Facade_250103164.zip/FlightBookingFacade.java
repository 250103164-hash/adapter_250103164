public class FlightBookingFacade {

    private final SeatInventorySystem seatSystem;
    private final BaggagePricingEngine baggageEngine;
    private final CurrencyConverter currencyConverter;
    private final PaymentProcessor paymentProcessor;
    private final TicketIssuer ticketIssuer;

    public FlightBookingFacade() {

        this.seatSystem = new SeatInventorySystem();
        this.baggageEngine = new BaggagePricingEngine();
        this.currencyConverter = new CurrencyConverter();
        this.paymentProcessor = new PaymentProcessor();
        this.ticketIssuer = new TicketIssuer();
    }

    // Phase 1: Original method
    public String bookFlight(String passengerName,
                             String flightCode,
                             String seatNumber,
                             double baseFareUSD,
                             int bagCount,
                             double bagWeightKg,
                             String currency,
                             String cardNumber) {

        return bookFlight(
                passengerName,
                flightCode,
                seatNumber,
                baseFareUSD,
                bagCount,
                bagWeightKg,
                currency,
                cardNumber,
                "STANDARD"
        );
    }

    // Phase 2: New method with loyalty tier
    public String bookFlight(String passengerName,
                             String flightCode,
                             String seatNumber,
                             double baseFareUSD,
                             int bagCount,
                             double bagWeightKg,
                             String currency,
                             String cardNumber,
                             String loyaltyTier) {

        String lockToken = null;

        try {

            // Connect to server
            seatSystem.connectToReservationServer();

            // Lock seat
            lockToken = seatSystem.lockSeat(
                    flightCode, seatNumber, passengerName
            );

            // Calculate baggage fee
            double baggageFee = 0.0;

            if (!loyaltyTier.equalsIgnoreCase("SILVER")
                    && !loyaltyTier.equalsIgnoreCase("GOLD")) {

                baggageFee = baggageEngine.calculateBaggageFeeUSD(
                        bagCount, bagWeightKg
                );
            }

            // Calculate total
            double totalUSD = baseFareUSD + baggageFee;

            // Convert currency
            double convertedTotal = currencyConverter.convertFromUSD(
                    totalUSD, currency
            );

            // Initialize payment
            paymentProcessor.initializeGateway();

            // Apply Silver discount
            if (loyaltyTier.equalsIgnoreCase("SILVER")) {
                paymentProcessor.applyPromoCode("SILVER-FREE-BAG");
            }

            // Charge card
            String receiptId = paymentProcessor.chargeCard(
                    cardNumber, convertedTotal, currency
            );

            // Generate ticket
            return ticketIssuer.generateTicket(
                    passengerName,
                    flightCode,
                    lockToken,
                    receiptId
            );

        } catch (RuntimeException ex) {

            if (lockToken != null) {
                seatSystem.releaseSeatLock(lockToken);
            }

            System.out.println("Booking failed: " + ex.getMessage());

            return "BOOKING_FAILED: " + ex.getMessage();

        } finally {

            seatSystem.disconnect();
        }
    }
}